package hi;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class mainproject extends JFrame {

    JPanel MonthsPanel, JanPan1, JanPan2, FebPan1, FebPan2, MarPan1, Marpan2, AprPan1, AprPan2, MayPan1, Maypan2, JunPan1, JunPan2, JulPan1, JulPan2, AugPan1, AugPan2, SepPan1, SepPan2, OctPan1, OctPan2, NovPan1, NovPan2, DecPan1, DecPan2;
    JButton JanBtn, FebBtn, MarchBtn, AprBtn, MayBtn, JunBtn, JulBtn, AugBtn, SepBtn, OctBtn, NovBtn, DecBtn;
    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12;

    public mainproject() {

        setSize(800, 800);
        setLayout(null);
        setDefaultCloseOperation(3);
        setLocationRelativeTo(null);

        Font font = (new Font("Arial", Font.BOLD, 30));
        Font font1 = (new Font("Arial", Font.ITALIC, 10));

        MonthsPanel = new JPanel();
        MonthsPanel.setBackground(Color.CYAN);
        MonthsPanel.setLayout(new GridLayout(2, 6));
        MonthsPanel.setBounds(0, 502, 800, 250);
        add(MonthsPanel);

        JanBtn = new JButton("January");
        FebBtn = new JButton("February");
        MarchBtn = new JButton("March");
        AprBtn = new JButton("April");
        MayBtn = new JButton("May");
        JunBtn = new JButton("June");
        JulBtn = new JButton("July");
        AugBtn = new JButton("August");
        SepBtn = new JButton("September");
        OctBtn = new JButton("October");
        NovBtn = new JButton("November");
        DecBtn = new JButton("December");


        MonthsPanel.add(JanBtn);
        MonthsPanel.add(FebBtn);
        MonthsPanel.add(MarchBtn);
        MonthsPanel.add(AprBtn);
        MonthsPanel.add(MayBtn);
        MonthsPanel.add(JunBtn);
        MonthsPanel.add(JulBtn);
        MonthsPanel.add(AugBtn);
        MonthsPanel.add(SepBtn);
        MonthsPanel.add(OctBtn);
        MonthsPanel.add(NovBtn);
        MonthsPanel.add(DecBtn);


        //JanurayPanel

        JanPan1 = new JPanel();
        JanPan1.setBounds(0, 0, 800, 100);
        JanPan1.setBackground(Color.gray);
        add(JanPan1);

        l1 = new JLabel("January, 2022");
        l1.setFont(font);
        JanPan1.add(l1);

        JanPan2 = new JPanel();
        JanPan2.setBounds(0, 101, 800, 399);
        JanPan2.setBackground(Color.blue);
        JanPan2.setLayout(new GridLayout(6, 7));
        add(JanPan2);


        JButton btnSun1 = new JButton("Sun");
        JButton btnMon1 = new JButton("Mon");
        JButton btnTue1 = new JButton("Tue");
        JButton btnWed1 = new JButton("Wed");
        JButton btnThu1 = new JButton("Thu");
        JButton btnFri1 = new JButton("Fri");
        btnFri1.setForeground(Color.red);
        JButton btnSat1 = new JButton("Sat");
        btnSat1.setForeground(Color.red);
        JButton btnJan1 = new JButton("30");
        JButton btnJan2 = new JButton("31");
        JButton btnJan3 = new JButton("");
        JButton btnJan4 = new JButton("");
        JButton btnJan5 = new JButton("");
        JButton btnJan6 = new JButton("");
        btnJan6.setBackground(Color.red);
        JButton btnJan7 = new JButton("1");
        btnJan7.setBackground(Color.red);
        JButton btnJan8 = new JButton("2");
        JButton btnJan9 = new JButton("3");
        JButton btnJan10 = new JButton("4");
        JButton btnJan11 = new JButton("5");
        JButton btnJan12 = new JButton("6");
        JButton btnJan13 = new JButton("7");
        btnJan13.setBackground(Color.red);
        JButton btnJan14 = new JButton("8");
        btnJan14.setBackground(Color.red);
        JButton btnJan15 = new JButton("9");
        JButton btnJan16 = new JButton("10");
        JButton btnJan17 = new JButton("11");
        JButton btnJan18 = new JButton("12");
        JButton btnJan19 = new JButton("13");
        JButton btnJan20 = new JButton("14");
        btnJan20.setBackground(Color.red);
        JButton btnJan21 = new JButton("15");
        btnJan21.setBackground(Color.red);
        JButton btnJan22 = new JButton("16");
        JButton btnJan23 = new JButton("17");
        JButton btnJan24 = new JButton("18");
        JButton btnJan25 = new JButton("19");
        JButton btnJan26 = new JButton("20");
        JButton btnJan27 = new JButton("21");
        btnJan27.setBackground(Color.red);
        JButton btnJan28 = new JButton("22");
        btnJan28.setBackground(Color.red);
        JButton btnJan29 = new JButton("23");
        JButton btnJan30 = new JButton("24");
        JButton btnJan31 = new JButton("25");
        JButton btnJan32 = new JButton("26");
        JButton btnJan33 = new JButton("27");
        JButton btnJan34 = new JButton("28");
        btnJan34.setBackground(Color.red);
        JButton btnJan35 = new JButton("29");
        btnJan35.setBackground(Color.red);


        //adding buttons to the Panels
        JanPan2.add(btnSun1);
        JanPan2.add(btnMon1);
        JanPan2.add(btnTue1);
        JanPan2.add(btnWed1);
        JanPan2.add(btnThu1);
        JanPan2.add(btnFri1);
        JanPan2.add(btnSat1);
        JanPan2.add(btnJan1);
        JanPan2.add(btnJan2);
        JanPan2.add(btnJan3);
        JanPan2.add(btnJan4);
        JanPan2.add(btnJan5);
        JanPan2.add(btnJan6);
        JanPan2.add(btnJan7);
        JanPan2.add(btnJan8);
        JanPan2.add(btnJan9);
        JanPan2.add(btnJan10);
        JanPan2.add(btnJan11);
        JanPan2.add(btnJan12);
        JanPan2.add(btnJan13);
        JanPan2.add(btnJan14);
        JanPan2.add(btnJan15);
        JanPan2.add(btnJan16);
        JanPan2.add(btnJan17);
        JanPan2.add(btnJan18);
        JanPan2.add(btnJan19);
        JanPan2.add(btnJan20);
        JanPan2.add(btnJan21);
        JanPan2.add(btnJan22);
        JanPan2.add(btnJan23);
        JanPan2.add(btnJan24);
        JanPan2.add(btnJan25);
        JanPan2.add(btnJan26);
        JanPan2.add(btnJan27);
        JanPan2.add(btnJan28);
        JanPan2.add(btnJan29);
        JanPan2.add(btnJan30);
        JanPan2.add(btnJan31);
        JanPan2.add(btnJan32);
        JanPan2.add(btnJan33);
        JanPan2.add(btnJan34);
        JanPan2.add(btnJan35);


        //February Panel

        FebPan1 = new JPanel();
        FebPan1.setBounds(0, 0, 800, 100);
        FebPan1.setBackground(Color.gray);

        l2 = new JLabel("February, 2022");
        l2.setFont(font);
        FebPan1.add(l2);
        FebPan1.add(l2);

        FebPan2 = new JPanel();
        FebPan2.setBounds(0, 101, 800, 399);
        FebPan2.setBackground(Color.blue);
        FebPan2.setLayout(new GridLayout(6, 7));
        add(FebPan2);

        JButton btnSun = new JButton("Sun");
        JButton btnMon = new JButton("Mon");
        JButton btnTue = new JButton("Tue");
        JButton btnWed = new JButton("Wed");
        JButton btnThu = new JButton("Thu");
        JButton btnFri = new JButton("Fri");
        JButton btnSat = new JButton("Sat");
        JButton btnF1 = new JButton("");
        JButton btnF2 = new JButton("");
        JButton btnF3 = new JButton("1");
        JButton btnF4 = new JButton("2");
        JButton btnF5 = new JButton("3");
        JButton btnF6 = new JButton("4");
        JButton btnF7 = new JButton("5");
        JButton btnF8 = new JButton("6");
        JButton btnF9 = new JButton("7");
        JButton btnF10 = new JButton("8");
        JButton btnF11 = new JButton("9");
        JButton btnF12 = new JButton("10");
        JButton btnF13 = new JButton("11");
        JButton btnF14 = new JButton("12");
        JButton btnF15 = new JButton("13");
        JButton btnF16 = new JButton("14");
        JButton btnF17 = new JButton("15");
        JButton btnF18 = new JButton("16");
        JButton btnF19 = new JButton("17");
        JButton btnF20 = new JButton("18");
        JButton btnF21 = new JButton("19");
        JButton btnF22 = new JButton("20");
        JButton btnF23 = new JButton("21");
        JButton btnF24 = new JButton("22");
        JButton btnF25 = new JButton("23");
        JButton btnF26 = new JButton("24");
        JButton btnF27 = new JButton("25");
        JButton btnF28 = new JButton("26");
        JButton btnF29 = new JButton("27");
        JButton btnF30 = new JButton("28");
        JButton btnF31 = new JButton("");
        JButton btnF32 = new JButton("");
        JButton btnF33 = new JButton("");
        JButton btnF34 = new JButton("");
        JButton btnF35 = new JButton("");

        FebPan2.add(btnSun);
        FebPan2.add(btnMon);
        FebPan2.add(btnTue);
        FebPan2.add(btnWed);
        FebPan2.add(btnThu);
        FebPan2.add(btnFri);
        FebPan2.add(btnSat);
        FebPan2.add(btnF1);
        FebPan2.add(btnF2);
        FebPan2.add(btnF3);
        FebPan2.add(btnF4);
        FebPan2.add(btnF5);
        FebPan2.add(btnF6);
        FebPan2.add(btnF7);
        FebPan2.add(btnF8);
        FebPan2.add(btnF9);
        FebPan2.add(btnF10);
        FebPan2.add(btnF11);
        FebPan2.add(btnF12);
        FebPan2.add(btnF13);
        FebPan2.add(btnF14);
        FebPan2.add(btnF15);
        FebPan2.add(btnF16);
        FebPan2.add(btnF17);
        FebPan2.add(btnF18);
        FebPan2.add(btnF19);
        FebPan2.add(btnF20);
        FebPan2.add(btnF21);
        FebPan2.add(btnF22);
        FebPan2.add(btnF23);
        FebPan2.add(btnF24);
        FebPan2.add(btnF25);
        FebPan2.add(btnF26);
        FebPan2.add(btnF27);
        FebPan2.add(btnF28);
        FebPan2.add(btnF29);
        FebPan2.add(btnF30);
        FebPan2.add(btnF31);
        FebPan2.add(btnF32);
        FebPan2.add(btnF33);
        FebPan2.add(btnF34);
        FebPan2.add(btnF35);

        //March Panel--------------------------------

        MarPan1 = new JPanel();
        MarPan1.setBounds(0, 0, 800, 100);
        MarPan1.setBackground(Color.gray);
        add(MarPan1);

        l3 = new JLabel("March, 2022");
        l3.setFont(font);
        MarPan1.add(l3);


        Marpan2 = new JPanel();
        Marpan2.setBounds(0, 101, 800, 399);
        Marpan2.setBackground(Color.blue);
        Marpan2.setLayout(new GridLayout(6, 7));
        add(Marpan2);

        JButton btnSun3 = new JButton("Sun");
        JButton btnMon3 = new JButton("Mon");
        JButton btnTue3 = new JButton("Tue");
        JButton btnWed3 = new JButton("Wed");
        JButton btnThu3 = new JButton("Thu");
        JButton btnFri3 = new JButton("Fri");
        JButton btnSat3 = new JButton("Sat");
        JButton btnM1 = new JButton("");
        JButton btnM2 = new JButton("");
        JButton btnM3 = new JButton("1");
        JButton btnM4 = new JButton("2");
        JButton btnM5 = new JButton("3");
        JButton btnM6 = new JButton("4");
        JButton btnM7 = new JButton("5");
        JButton btnM8 = new JButton("6");
        JButton btnM9 = new JButton("7");
        JButton btnM10 = new JButton("8");
        JButton btnM11 = new JButton("9");
        JButton btnM12 = new JButton("10");
        JButton btnM13 = new JButton("11");
        JButton btnM14 = new JButton("12");
        JButton btnM15 = new JButton("13");
        JButton btnM16 = new JButton("14");
        JButton btnM17 = new JButton("15");
        JButton btnM18 = new JButton("16");
        JButton btnM19 = new JButton("17");
        JButton btnM20 = new JButton("18");
        JButton btnM21 = new JButton("19");
        JButton btnM22 = new JButton("20");
        JButton btnM23 = new JButton("21");
        JButton btnM24 = new JButton("22");
        JButton btnM25 = new JButton("23");
        JButton btnM26 = new JButton("24");
        JButton btnM27 = new JButton("25");
        JButton btnM28 = new JButton("26");
        JButton btnM29 = new JButton("27");
        JButton btnM30 = new JButton("28");
        JButton btnM31 = new JButton("29");
        JButton btnM32 = new JButton("30");
        JButton btnM33 = new JButton("31");
        JButton btnM34 = new JButton("");
        JButton btnM35 = new JButton("");

        Marpan2.add(btnSun3);
        Marpan2.add(btnMon3);
        Marpan2.add(btnTue3);
        Marpan2.add(btnWed3);
        Marpan2.add(btnThu3);
        Marpan2.add(btnFri3);
        Marpan2.add(btnSat3);
        Marpan2.add(btnM1);
        Marpan2.add(btnM2);
        Marpan2.add(btnM3);
        Marpan2.add(btnM4);
        Marpan2.add(btnM5);
        Marpan2.add(btnM6);
        Marpan2.add(btnM7);
        Marpan2.add(btnM8);
        Marpan2.add(btnM9);
        Marpan2.add(btnM10);
        Marpan2.add(btnM11);
        Marpan2.add(btnM12);
        Marpan2.add(btnM13);
        Marpan2.add(btnM14);
        Marpan2.add(btnM15);
        Marpan2.add(btnM16);
        Marpan2.add(btnM17);
        Marpan2.add(btnM18);
        Marpan2.add(btnM19);
        Marpan2.add(btnM20);
        Marpan2.add(btnM21);
        Marpan2.add(btnM22);
        Marpan2.add(btnM23);
        Marpan2.add(btnM24);
        Marpan2.add(btnM25);
        Marpan2.add(btnM26);
        Marpan2.add(btnM27);
        Marpan2.add(btnM28);
        Marpan2.add(btnM29);
        Marpan2.add(btnM30);
        Marpan2.add(btnM31);
        Marpan2.add(btnM32);
        Marpan2.add(btnM33);
        Marpan2.add(btnM34);
        Marpan2.add(btnM35);

        //April Panel--------------------------------

        AprPan1 = new JPanel();
        AprPan1.setBounds(0, 0, 800, 100);
        AprPan1.setBackground(Color.gray);
        add(AprPan1);

        l4 = new JLabel("April, 2022");
        l4.setFont(font);
        AprPan1.add(l4);


        AprPan2 = new JPanel();
        AprPan2.setBounds(0, 101, 800, 399);
        AprPan2.setBackground(Color.blue);
        AprPan2.setLayout(new GridLayout(6, 7));
        add(AprPan2);

        JButton btnSun4 = new JButton("Sun");
        JButton btnMon4 = new JButton("Mon");
        JButton btnTue4 = new JButton("Tue");
        JButton btnWed4 = new JButton("Wed");
        JButton btnThu4 = new JButton("Thu");
        JButton btnFri4 = new JButton("Fri");
        JButton btnSat4 = new JButton("Sat");
        JButton btnA1 = new JButton("");
        JButton btnA2 = new JButton("");
        JButton btnA3 = new JButton("");
        JButton btnA4 = new JButton("");
        JButton btnA5 = new JButton("");
        JButton btnA6 = new JButton("1");
        JButton btnA7 = new JButton("2");
        JButton btnA8 = new JButton("3");
        JButton btnA9 = new JButton("4");
        JButton btnA10 = new JButton("5");
        JButton btnA11 = new JButton("6");
        JButton btnA12 = new JButton("7");
        JButton btnA13 = new JButton("8");
        JButton btnA14 = new JButton("9");
        JButton btnA15 = new JButton("10");
        JButton btnA16 = new JButton("11");
        JButton btnA17 = new JButton("12");
        JButton btnA18 = new JButton("13");
        JButton btnA19 = new JButton("14");
        JButton btnA20 = new JButton("15");
        JButton btnA21 = new JButton("16");
        JButton btnA22 = new JButton("17");
        JButton btnA23 = new JButton("18");
        JButton btnA24 = new JButton("19");
        JButton btnA25 = new JButton("20");
        JButton btnA26 = new JButton("21");
        JButton btnA27 = new JButton("22");
        JButton btnA28 = new JButton("23");
        JButton btnA29 = new JButton("24");
        JButton btnA30 = new JButton("25");
        JButton btnA31 = new JButton("26");
        JButton btnA32 = new JButton("27");
        JButton btnA33 = new JButton("28");
        JButton btnA34 = new JButton("29");
        JButton btnA35 = new JButton("30");

        AprPan2.add(btnSun4);
        AprPan2.add(btnMon4);
        AprPan2.add(btnTue4);
        AprPan2.add(btnWed4);
        AprPan2.add(btnThu4);
        AprPan2.add(btnFri4);
        AprPan2.add(btnSat4);
        AprPan2.add(btnA1);
        AprPan2.add(btnA2);
        AprPan2.add(btnA3);
        AprPan2.add(btnA4);
        AprPan2.add(btnA5);
        AprPan2.add(btnA6);
        AprPan2.add(btnA7);
        AprPan2.add(btnA8);
        AprPan2.add(btnA9);
        AprPan2.add(btnA10);
        AprPan2.add(btnA11);
        AprPan2.add(btnA12);
        AprPan2.add(btnA13);
        AprPan2.add(btnA14);
        AprPan2.add(btnA15);
        AprPan2.add(btnA16);
        AprPan2.add(btnA17);
        AprPan2.add(btnA18);
        AprPan2.add(btnA19);
        AprPan2.add(btnA20);
        AprPan2.add(btnA21);
        AprPan2.add(btnA22);
        AprPan2.add(btnA23);
        AprPan2.add(btnA24);
        AprPan2.add(btnA25);
        AprPan2.add(btnA26);
        AprPan2.add(btnA27);
        AprPan2.add(btnA28);
        AprPan2.add(btnA29);
        AprPan2.add(btnA30);
        AprPan2.add(btnA31);
        AprPan2.add(btnA32);
        AprPan2.add(btnA33);
        AprPan2.add(btnA34);
        AprPan2.add(btnA35);

        //May Panel--------------------------------

        MayPan1 = new JPanel();
        MayPan1.setBounds(0, 0, 800, 100);
        MayPan1.setBackground(Color.gray);
        add(MayPan1);

        l5 = new JLabel("May, 2022");
        l5.setFont(font);
        MayPan1.add(l5);


        Maypan2 = new JPanel();
        Maypan2.setBounds(0, 101, 800, 399);
        Maypan2.setBackground(Color.blue);
        Maypan2.setLayout(new GridLayout(6, 7));
        add(Maypan2);

        JButton btnSun5 = new JButton("Sun");
        JButton btnMon5 = new JButton("Mon");
        JButton btnTue5 = new JButton("Tue");
        JButton btnWed5 = new JButton("Wed");
        JButton btnThu5 = new JButton("Thu");
        JButton btnFri5 = new JButton("Fri");
        JButton btnSat5 = new JButton("Sat");
        JButton btnMa1 = new JButton("1");
        JButton btnMa2 = new JButton("2");
        JButton btnMa3 = new JButton("3");
        JButton btnMa4 = new JButton("4");
        JButton btnMa5 = new JButton("5");
        JButton btnMa6 = new JButton("6");
        JButton btnMa7 = new JButton("7");
        JButton btnMa8 = new JButton("8");
        JButton btnMa9 = new JButton("9");
        JButton btnMa10 = new JButton("10");
        JButton btnMa11 = new JButton("11");
        JButton btnMa12 = new JButton("12");
        JButton btnMa13 = new JButton("13");
        JButton btnMa14 = new JButton("14");
        JButton btnMa15 = new JButton("15");
        JButton btnMa16 = new JButton("16");
        JButton btnMa17 = new JButton("17");
        JButton btnMa18 = new JButton("18");
        JButton btnMa19 = new JButton("19");
        JButton btnMa20 = new JButton("20");
        JButton btnMa21 = new JButton("21");
        JButton btnMa22 = new JButton("22");
        JButton btnMa23 = new JButton("23");
        JButton btnMa24 = new JButton("24");
        JButton btnMa25 = new JButton("25");
        JButton btnMa26 = new JButton("26");
        JButton btnMa27 = new JButton("27");
        JButton btnMa28 = new JButton("28");
        JButton btnMa29 = new JButton("29");
        JButton btnMa30 = new JButton("30");
        JButton btnMa31 = new JButton("31");
        JButton btnMa32 = new JButton("");
        JButton btnMa33 = new JButton("");
        JButton btnMa34 = new JButton("");
        JButton btnMa35 = new JButton("");

        Maypan2.add(btnSun5);
        Maypan2.add(btnMon5);
        Maypan2.add(btnTue5);
        Maypan2.add(btnWed5);
        Maypan2.add(btnThu5);
        Maypan2.add(btnFri5);
        Maypan2.add(btnSat5);
        Maypan2.add(btnMa1);
        Maypan2.add(btnMa2);
        Maypan2.add(btnMa3);
        Maypan2.add(btnMa4);
        Maypan2.add(btnMa5);
        Maypan2.add(btnMa6);
        Maypan2.add(btnMa7);
        Maypan2.add(btnMa8);
        Maypan2.add(btnMa9);
        Maypan2.add(btnMa10);
        Maypan2.add(btnMa11);
        Maypan2.add(btnMa12);
        Maypan2.add(btnMa13);
        Maypan2.add(btnMa14);
        Maypan2.add(btnMa15);
        Maypan2.add(btnMa16);
        Maypan2.add(btnMa17);
        Maypan2.add(btnMa18);
        Maypan2.add(btnMa19);
        Maypan2.add(btnMa20);
        Maypan2.add(btnMa21);
        Maypan2.add(btnMa22);
        Maypan2.add(btnMa23);
        Maypan2.add(btnMa24);
        Maypan2.add(btnMa25);
        Maypan2.add(btnMa26);
        Maypan2.add(btnMa27);
        Maypan2.add(btnMa28);
        Maypan2.add(btnMa29);
        Maypan2.add(btnMa30);
        Maypan2.add(btnMa31);
        Maypan2.add(btnMa32);
        Maypan2.add(btnMa33);
        Maypan2.add(btnMa34);
        Maypan2.add(btnMa35);

        //June Panel

        JunPan1 = new JPanel();
        JunPan1.setBounds(0, 0, 800, 100);
        JunPan1.setBackground(Color.gray);

        l6 = new JLabel("June, 2022");
        l6.setFont(font);
        JunPan1.add(l6);
        JunPan1.add(l6);

        JunPan2 = new JPanel();
        JunPan2.setBounds(0, 101, 800, 399);
        JunPan2.setBackground(Color.blue);
        JunPan2.setLayout(new GridLayout(6, 7));
        add(JunPan2);

        JButton btnSun6 = new JButton("Sun");
        JButton btnMon6 = new JButton("Mon");
        JButton btnTue6 = new JButton("Tue");
        JButton btnWed6 = new JButton("Wed");
        JButton btnThu6 = new JButton("Thu");
        JButton btnFri6 = new JButton("Fri");
        JButton btnSat6 = new JButton("Sat");
        JButton btnJun1 = new JButton("");
        JButton btnJun2 = new JButton("");
        JButton btnJun3 = new JButton("");
        JButton btnJun4 = new JButton("1");
        JButton btnJun5 = new JButton("2");
        JButton btnJun6 = new JButton("3");
        JButton btnJun7 = new JButton("4");
        JButton btnJun8 = new JButton("5");
        JButton btnJun9 = new JButton("6");
        JButton btnJun10 = new JButton("7");
        JButton btnJun11 = new JButton("8");
        JButton btnJun12 = new JButton("9");
        JButton btnJun13 = new JButton("10");
        JButton btnJun14 = new JButton("11");
        JButton btnJun15 = new JButton("12");
        JButton btnJun16 = new JButton("13");
        JButton btnJun17 = new JButton("14");
        JButton btnJun18 = new JButton("15");
        JButton btnJun19 = new JButton("16");
        JButton btnJun20 = new JButton("17");
        JButton btnJun21 = new JButton("18");
        JButton btnJun22 = new JButton("19");
        JButton btnJun23 = new JButton("20");
        JButton btnJun24 = new JButton("21");
        JButton btnJun25 = new JButton("22");
        JButton btnJun26 = new JButton("23");
        JButton btnJun27 = new JButton("24");
        JButton btnJun28 = new JButton("25");
        JButton btnJun29 = new JButton("26");
        JButton btnJun30 = new JButton("27");
        JButton btnJun31 = new JButton("28");
        JButton btnJun32 = new JButton("29");
        JButton btnJun33 = new JButton("30");
        JButton btnJun34 = new JButton("");
        JButton btnJun35 = new JButton("");

        JunPan2.add(btnSun6);
        JunPan2.add(btnMon6);
        JunPan2.add(btnTue6);
        JunPan2.add(btnWed6);
        JunPan2.add(btnThu6);
        JunPan2.add(btnFri6);
        JunPan2.add(btnSat6);
        JunPan2.add(btnJun1);
        JunPan2.add(btnJun2);
        JunPan2.add(btnJun3);
        JunPan2.add(btnJun4);
        JunPan2.add(btnJun5);
        JunPan2.add(btnJun6);
        JunPan2.add(btnJun7);
        JunPan2.add(btnJun8);
        JunPan2.add(btnJun9);
        JunPan2.add(btnJun10);
        JunPan2.add(btnJun11);
        JunPan2.add(btnJun12);
        JunPan2.add(btnJun13);
        JunPan2.add(btnJun14);
        JunPan2.add(btnJun15);
        JunPan2.add(btnJun16);
        JunPan2.add(btnJun17);
        JunPan2.add(btnJun18);
        JunPan2.add(btnJun19);
        JunPan2.add(btnJun20);
        JunPan2.add(btnJun21);
        JunPan2.add(btnJun22);
        JunPan2.add(btnJun23);
        JunPan2.add(btnJun24);
        JunPan2.add(btnJun25);
        JunPan2.add(btnJun26);
        JunPan2.add(btnJun27);
        JunPan2.add(btnJun28);
        JunPan2.add(btnJun29);
        JunPan2.add(btnJun30);
        JunPan2.add(btnJun31);
        JunPan2.add(btnJun32);
        JunPan2.add(btnJun33);
        JunPan2.add(btnJun34);
        JunPan2.add(btnJun35);


        //July Panel
        JulPan1 = new JPanel();
        JulPan1.setBounds(0, 0, 800, 100);
        JulPan1.setBackground(Color.GRAY);

        l7 = new JLabel("July, 2022");
        l7.setFont(font);
        JulPan1.add(l7);
        JulPan1.add(l7);

        JulPan2 = new JPanel();
        JulPan2.setBounds(0, 101, 800, 399);
        JulPan2.setBackground(Color.blue);
        JulPan2.setLayout(new GridLayout(6, 7));
        add(JulPan2);

        JButton btnSun7 = new JButton("Sun");
        JButton btnMon7 = new JButton("Mon");
        JButton btnTue7 = new JButton("Tue");
        JButton btnWed7 = new JButton("Wed");
        JButton btnThu7 = new JButton("Thu");
        JButton btnFri7 = new JButton("Fri");
        JButton btnSat7 = new JButton("Sat");
        JButton btnJul1 = new JButton("31");
        JButton btnJul2 = new JButton("");
        JButton btnJul3 = new JButton("");
        JButton btnJul4 = new JButton("");
        JButton btnJul5 = new JButton("");
        JButton btnJul6 = new JButton("1");
        JButton btnJul7 = new JButton("2");
        JButton btnJul8 = new JButton("3");
        JButton btnJul9 = new JButton("4");
        JButton btnJul10 = new JButton("5");
        JButton btnJul11 = new JButton("6");
        JButton btnJul12 = new JButton("7");
        JButton btnJul13 = new JButton("8");
        JButton btnJul14 = new JButton("9");
        JButton btnJul15 = new JButton("10");
        JButton btnJul16 = new JButton("11");
        JButton btnJul17 = new JButton("12");
        JButton btnJul18 = new JButton("13");
        JButton btnJul19 = new JButton("14");
        JButton btnJul20 = new JButton("15");
        JButton btnJul21 = new JButton("16");
        JButton btnJul22 = new JButton("17");
        JButton btnJul23 = new JButton("18");
        JButton btnJul24 = new JButton("19");
        JButton btnJul25 = new JButton("20");
        JButton btnJul26 = new JButton("21");
        JButton btnJul27 = new JButton("22");
        JButton btnJul28 = new JButton("23");
        JButton btnJul29 = new JButton("24");
        JButton btnJul30 = new JButton("25");
        JButton btnJul31 = new JButton("26");
        JButton btnJul32 = new JButton("27");
        JButton btnJul33 = new JButton("28");
        JButton btnJul34 = new JButton("29");
        JButton btnJul35 = new JButton("30");

        JulPan2.add(btnSun7);
        JulPan2.add(btnMon7);
        JulPan2.add(btnTue7);
        JulPan2.add(btnWed7);
        JulPan2.add(btnThu7);
        JulPan2.add(btnFri7);
        JulPan2.add(btnSat7);
        JulPan2.add(btnJul1);
        JulPan2.add(btnJul2);
        JulPan2.add(btnJul3);
        JulPan2.add(btnJul4);
        JulPan2.add(btnJul5);
        JulPan2.add(btnJul6);
        JulPan2.add(btnJul7);
        JulPan2.add(btnJul8);
        JulPan2.add(btnJul9);
        JulPan2.add(btnJul10);
        JulPan2.add(btnJul11);
        JulPan2.add(btnJul12);
        JulPan2.add(btnJul13);
        JulPan2.add(btnJul14);
        JulPan2.add(btnJul15);
        JulPan2.add(btnJul16);
        JulPan2.add(btnJul17);
        JulPan2.add(btnJul18);
        JulPan2.add(btnJul19);
        JulPan2.add(btnJul20);
        JulPan2.add(btnJul21);
        JulPan2.add(btnJul22);
        JulPan2.add(btnJul23);
        JulPan2.add(btnJul24);
        JulPan2.add(btnJul25);
        JulPan2.add(btnJul26);
        JulPan2.add(btnJul27);
        JulPan2.add(btnJul28);
        JulPan2.add(btnJul29);
        JulPan2.add(btnJul30);
        JulPan2.add(btnJul31);
        JulPan2.add(btnJul32);
        JulPan2.add(btnJul33);
        JulPan2.add(btnJul34);
        JulPan2.add(btnJul35);


        //August Panel

        AugPan1 = new JPanel();
        AugPan1.setBounds(0, 0, 800, 100);
        AugPan1.setBackground(Color.gray);

        l8 = new JLabel("August, 2022");
        l8.setFont(font);
        AugPan1.add(l8);
        AugPan1.add(l8);

        AugPan2 = new JPanel();
        AugPan2.setBounds(0, 101, 800, 399);
        AugPan2.setBackground(Color.blue);
        AugPan2.setLayout(new GridLayout(6, 7));
        add(AugPan2);

        JButton btnSun8 = new JButton("Sun");
        JButton btnMon8 = new JButton("Mon");
        JButton btnTue8 = new JButton("Tue");
        JButton btnWed8 = new JButton("Wed");
        JButton btnThu8 = new JButton("Thu");
        JButton btnFri8 = new JButton("Fri");
        JButton btnSat8 = new JButton("Sat");
        JButton btnAug1 = new JButton("");
        JButton btnAug2 = new JButton("1");
        JButton btnAug3 = new JButton("2");
        JButton btnAug4 = new JButton("3");
        JButton btnAug5 = new JButton("4");
        JButton btnAug6 = new JButton("5");
        JButton btnAug7 = new JButton("6");
        JButton btnAug8 = new JButton("7");
        JButton btnAug9 = new JButton("8");
        JButton btnAug10 = new JButton("9");
        JButton btnAug11 = new JButton("10");
        JButton btnAug12 = new JButton("11");
        JButton btnAug13 = new JButton("12");
        JButton btnAug14 = new JButton("13");
        JButton btnAug15 = new JButton("14");
        JButton btnAug16 = new JButton("15");
        JButton btnAug17 = new JButton("16");
        JButton btnAug18 = new JButton("17");
        JButton btnAug19 = new JButton("18");
        JButton btnAug20 = new JButton("19");
        JButton btnAug21 = new JButton("20");
        JButton btnAug22 = new JButton("21");
        JButton btnAug23 = new JButton("22");
        JButton btnAug24 = new JButton("23");
        JButton btnAug25 = new JButton("24");
        JButton btnAug26 = new JButton("25");
        JButton btnAug27 = new JButton("26");
        JButton btnAug28 = new JButton("27");
        JButton btnAug29 = new JButton("28");
        JButton btnAug30 = new JButton("29");
        JButton btnAug31 = new JButton("30");
        JButton btnAug32 = new JButton("31");
        JButton btnAug33 = new JButton("");
        JButton btnAug34 = new JButton("");
        JButton btnAug35 = new JButton("");

        AugPan2.add(btnSun8);
        AugPan2.add(btnMon8);
        AugPan2.add(btnTue8);
        AugPan2.add(btnWed8);
        AugPan2.add(btnThu8);
        AugPan2.add(btnFri8);
        AugPan2.add(btnSat8);
        AugPan2.add(btnAug1);
        AugPan2.add(btnAug2);
        AugPan2.add(btnAug3);
        AugPan2.add(btnAug4);
        AugPan2.add(btnAug5);
        AugPan2.add(btnAug6);
        AugPan2.add(btnAug7);
        AugPan2.add(btnAug8);
        AugPan2.add(btnAug9);
        AugPan2.add(btnAug10);
        AugPan2.add(btnAug11);
        AugPan2.add(btnAug12);
        AugPan2.add(btnAug13);
        AugPan2.add(btnAug14);
        AugPan2.add(btnAug15);
        AugPan2.add(btnAug16);
        AugPan2.add(btnAug17);
        AugPan2.add(btnAug18);
        AugPan2.add(btnAug19);
        AugPan2.add(btnAug20);
        AugPan2.add(btnAug21);
        AugPan2.add(btnAug22);
        AugPan2.add(btnAug23);
        AugPan2.add(btnAug24);
        AugPan2.add(btnAug25);
        AugPan2.add(btnAug26);
        AugPan2.add(btnAug27);
        AugPan2.add(btnAug28);
        AugPan2.add(btnAug29);
        AugPan2.add(btnAug30);
        AugPan2.add(btnAug31);
        AugPan2.add(btnAug32);
        AugPan2.add(btnAug33);
        AugPan2.add(btnAug34);
        AugPan2.add(btnAug35);

        //September Panel

        SepPan1 = new JPanel();
        SepPan1.setBounds(0, 0, 800, 100);
        SepPan1.setBackground(Color.gray);

        l9 = new JLabel("September, 2022");
        l9.setFont(font);
        SepPan1.add(l9);
        SepPan1.add(l9);

        SepPan2 = new JPanel();
        SepPan2.setBounds(0, 101, 800, 399);
        SepPan2.setBackground(Color.blue);
        SepPan2.setLayout(new GridLayout(6, 7));
        add(SepPan2);

        JButton btnSun9 = new JButton("Sun");
        JButton btnMon9 = new JButton("Mon");
        JButton btnTue9 = new JButton("Tue");
        JButton btnWed9 = new JButton("Wed");
        JButton btnThu9 = new JButton("Thu");
        JButton btnFri9 = new JButton("Fri");
        JButton btnSat9 = new JButton("Sat");
        JButton btnSep1 = new JButton("");
        JButton btnSep2 = new JButton("");
        JButton btnSep3 = new JButton("");
        JButton btnSep4 = new JButton("");
        JButton btnSep5 = new JButton("1");
        JButton btnSep6 = new JButton("2");
        JButton btnSep7 = new JButton("3");
        JButton btnSep8 = new JButton("4");
        JButton btnSep9 = new JButton("5");
        JButton btnSep10 = new JButton("6");
        JButton btnSep11 = new JButton("7");
        JButton btnSep12 = new JButton("8");
        JButton btnSep13 = new JButton("9");
        JButton btnSep14 = new JButton("10");
        JButton btnSep15 = new JButton("11");
        JButton btnSep16 = new JButton("12");
        JButton btnSep17 = new JButton("13");
        JButton btnSep18 = new JButton("14");
        JButton btnSep19 = new JButton("15");
        JButton btnSep20 = new JButton("16");
        JButton btnSep21 = new JButton("17");
        JButton btnSep22 = new JButton("18");
        JButton btnSep23 = new JButton("19");
        JButton btnSep24 = new JButton("20");
        JButton btnSep25 = new JButton("21");
        JButton btnSep26 = new JButton("22");
        JButton btnSep27 = new JButton("23");
        JButton btnSep28 = new JButton("24");
        JButton btnSep29 = new JButton("25");
        JButton btnSep30 = new JButton("26");
        JButton btnSep31 = new JButton("27");
        JButton btnSep32 = new JButton("28");
        JButton btnSep33 = new JButton("29");
        JButton btnSep34 = new JButton("30");
        JButton btnSep35 = new JButton("");

        SepPan2.add(btnSun9);
        SepPan2.add(btnMon9);
        SepPan2.add(btnTue9);
        SepPan2.add(btnWed9);
        SepPan2.add(btnThu9);
        SepPan2.add(btnFri9);
        SepPan2.add(btnSat9);
        SepPan2.add(btnSep1);
        SepPan2.add(btnSep2);
        SepPan2.add(btnSep3);
        SepPan2.add(btnSep4);
        SepPan2.add(btnSep5);
        SepPan2.add(btnSep6);
        SepPan2.add(btnSep7);
        SepPan2.add(btnSep8);
        SepPan2.add(btnSep9);
        SepPan2.add(btnSep10);
        SepPan2.add(btnSep11);
        SepPan2.add(btnSep12);
        SepPan2.add(btnSep13);
        SepPan2.add(btnSep14);
        SepPan2.add(btnSep15);
        SepPan2.add(btnSep16);
        SepPan2.add(btnSep17);
        SepPan2.add(btnSep18);
        SepPan2.add(btnSep19);
        SepPan2.add(btnSep20);
        SepPan2.add(btnSep21);
        SepPan2.add(btnSep22);
        SepPan2.add(btnSep23);
        SepPan2.add(btnSep24);
        SepPan2.add(btnSep25);
        SepPan2.add(btnSep26);
        SepPan2.add(btnSep27);
        SepPan2.add(btnSep28);
        SepPan2.add(btnSep29);
        SepPan2.add(btnSep30);
        SepPan2.add(btnSep31);
        SepPan2.add(btnSep32);
        SepPan2.add(btnSep33);
        SepPan2.add(btnSep34);
        SepPan2.add(btnSep35);

        //October Panel

        OctPan1 = new JPanel();
        OctPan1.setBounds(0, 0, 800, 100);
        OctPan1.setBackground(Color.gray);

        l10 = new JLabel("October, 2022");
        l10.setFont(font);
        OctPan1.add(l10);
        OctPan1.add(l10);

        OctPan2 = new JPanel();
        OctPan2.setBounds(0, 101, 800, 399);
        OctPan2.setBackground(Color.blue);
        OctPan2.setLayout(new GridLayout(6, 7));
        add(OctPan2);

        JButton btnSun10 = new JButton("Sun");
        JButton btnMon10 = new JButton("Mon");
        JButton btnTue10 = new JButton("Tue");
        JButton btnWed10 = new JButton("Wed");
        JButton btnThu10 = new JButton("Thu");
        JButton btnFri10 = new JButton("Fri");
        JButton btnSat10 = new JButton("Sat");
        JButton btnOct1 = new JButton("30");
        JButton btnOct2 = new JButton("31");
        JButton btnOct3 = new JButton("");
        JButton btnOct4 = new JButton("");
        JButton btnOct5 = new JButton("");
        JButton btnOct6 = new JButton("");
        JButton btnOct7 = new JButton("1");
        JButton btnOct8 = new JButton("2");
        JButton btnOct9 = new JButton("3");
        JButton btnOct10 = new JButton("4");
        JButton btnOct11 = new JButton("5");
        JButton btnOct12 = new JButton("6");
        JButton btnOct13 = new JButton("7");
        JButton btnOct14 = new JButton("8");
        JButton btnOct15 = new JButton("9");
        JButton btnOct16 = new JButton("10");
        JButton btnOct17 = new JButton("11");
        JButton btnOct18 = new JButton("12");
        JButton btnOct19 = new JButton("13");
        JButton btnOct20 = new JButton("14");
        JButton btnOct21 = new JButton("15");
        JButton btnOct22 = new JButton("16");
        JButton btnOct23 = new JButton("17");
        JButton btnOct24 = new JButton("18");
        JButton btnOct25 = new JButton("19");
        JButton btnOct26 = new JButton("20");
        JButton btnOct27 = new JButton("21");
        JButton btnOct28 = new JButton("22");
        JButton btnOct29 = new JButton("23");
        JButton btnOct30 = new JButton("24");
        JButton btnOct31 = new JButton("25");
        JButton btnOct32 = new JButton("26");
        JButton btnOct33 = new JButton("27");
        JButton btnOct34 = new JButton("28");
        JButton btnOct35 = new JButton("29");

        OctPan2.add(btnSun10);
        OctPan2.add(btnMon10);
        OctPan2.add(btnTue10);
        OctPan2.add(btnWed10);
        OctPan2.add(btnThu10);
        OctPan2.add(btnFri10);
        OctPan2.add(btnSat10);
        OctPan2.add(btnOct1);
        OctPan2.add(btnOct2);
        OctPan2.add(btnOct3);
        OctPan2.add(btnOct4);
        OctPan2.add(btnOct5);
        OctPan2.add(btnOct6);
        OctPan2.add(btnOct7);
        OctPan2.add(btnOct8);
        OctPan2.add(btnOct9);
        OctPan2.add(btnOct10);
        OctPan2.add(btnOct11);
        OctPan2.add(btnOct12);
        OctPan2.add(btnOct13);
        OctPan2.add(btnOct14);
        OctPan2.add(btnOct15);
        OctPan2.add(btnOct16);
        OctPan2.add(btnOct17);
        OctPan2.add(btnOct18);
        OctPan2.add(btnOct19);
        OctPan2.add(btnOct20);
        OctPan2.add(btnOct21);
        OctPan2.add(btnOct22);
        OctPan2.add(btnOct23);
        OctPan2.add(btnOct24);
        OctPan2.add(btnOct25);
        OctPan2.add(btnOct26);
        OctPan2.add(btnOct27);
        OctPan2.add(btnOct28);
        OctPan2.add(btnOct29);
        OctPan2.add(btnOct30);
        OctPan2.add(btnOct31);
        OctPan2.add(btnOct32);
        OctPan2.add(btnOct33);
        OctPan2.add(btnOct34);
        OctPan2.add(btnOct35);

        //November Panel

        NovPan1 = new JPanel();
        NovPan1.setBounds(0, 0, 800, 100);
        NovPan1.setBackground(Color.gray);

        l11 = new JLabel("November, 2022");
        l11.setFont(font);
        NovPan1.add(l11);
        NovPan1.add(l11);

        NovPan2 = new JPanel();
        NovPan2.setBounds(0, 101, 800, 399);
        NovPan2.setBackground(Color.blue);
        NovPan2.setLayout(new GridLayout(6, 7));
        add(NovPan2);

        JButton btnSun11 = new JButton("Sun");
        JButton btnMon11 = new JButton("Mon");
        JButton btnTue11 = new JButton("Tue");
        JButton btnWed11 = new JButton("Wed");
        JButton btnThu11 = new JButton("Thu");
        JButton btnFri11 = new JButton("Fri");
        JButton btnSat11 = new JButton("Sat");
        JButton btnNov1 = new JButton("");
        JButton btnNov2 = new JButton("");
        JButton btnNov3 = new JButton("1");
        JButton btnNov4 = new JButton("2");
        JButton btnNov5 = new JButton("3");
        JButton btnNov6 = new JButton("4");
        JButton btnNov7 = new JButton("5");
        JButton btnNov8 = new JButton("6");
        JButton btnNov9 = new JButton("7");
        JButton btnNov10 = new JButton("8");
        JButton btnNov11 = new JButton("9");
        JButton btnNov12 = new JButton("10");
        JButton btnNov13 = new JButton("11");
        JButton btnNov14 = new JButton("12");
        JButton btnNov15 = new JButton("13");
        JButton btnNov16 = new JButton("14");
        JButton btnNov17 = new JButton("15");
        JButton btnNov18 = new JButton("16");
        JButton btnNov19 = new JButton("17");
        JButton btnNov20 = new JButton("18");
        JButton btnNov21 = new JButton("19");
        JButton btnNov22 = new JButton("20");
        JButton btnNov23 = new JButton("21");
        JButton btnNov24 = new JButton("22");
        JButton btnNov25 = new JButton("23");
        JButton btnNov26 = new JButton("24");
        JButton btnNov27 = new JButton("25");
        JButton btnNov28 = new JButton("26");
        JButton btnNov29 = new JButton("27");
        JButton btnNov30 = new JButton("28");
        JButton btnNov31 = new JButton("29");
        JButton btnNov32 = new JButton("30");
        JButton btnNov33 = new JButton("");
        JButton btnNov34 = new JButton("");
        JButton btnNov35 = new JButton("");

        NovPan2.add(btnSun11);
        NovPan2.add(btnMon11);
        NovPan2.add(btnTue11);
        NovPan2.add(btnWed11);
        NovPan2.add(btnThu11);
        NovPan2.add(btnFri11);
        NovPan2.add(btnSat11);
        NovPan2.add(btnNov1);
        NovPan2.add(btnNov2);
        NovPan2.add(btnNov3);
        NovPan2.add(btnNov4);
        NovPan2.add(btnNov5);
        NovPan2.add(btnNov6);
        NovPan2.add(btnNov7);
        NovPan2.add(btnNov8);
        NovPan2.add(btnNov9);
        NovPan2.add(btnNov10);
        NovPan2.add(btnNov11);
        NovPan2.add(btnNov12);
        NovPan2.add(btnNov13);
        NovPan2.add(btnNov14);
        NovPan2.add(btnNov15);
        NovPan2.add(btnNov16);
        NovPan2.add(btnNov17);
        NovPan2.add(btnNov18);
        NovPan2.add(btnNov19);
        NovPan2.add(btnNov20);
        NovPan2.add(btnNov21);
        NovPan2.add(btnNov22);
        NovPan2.add(btnNov23);
        NovPan2.add(btnNov24);
        NovPan2.add(btnNov25);
        NovPan2.add(btnNov26);
        NovPan2.add(btnNov27);
        NovPan2.add(btnNov28);
        NovPan2.add(btnNov29);
        NovPan2.add(btnNov30);
        NovPan2.add(btnNov31);
        NovPan2.add(btnNov32);
        NovPan2.add(btnNov33);
        NovPan2.add(btnNov34);
        NovPan2.add(btnNov35);

        //December Panel--------------------------------

        DecPan1 = new JPanel();
        DecPan1.setBounds(0, 0, 800, 100);
        DecPan1.setBackground(Color.gray);

        l12 = new JLabel("December, 2022");
        l12.setFont(font);
        DecPan1.add(l12);


        DecPan2 = new JPanel();
        DecPan2.setBounds(0, 101, 800, 399);
        DecPan2.setBackground(Color.blue);
        DecPan2.setLayout(new GridLayout(6, 7));
        add(DecPan2);

        JButton btnSun12 = new JButton("Sun");
        JButton btnMon12 = new JButton("Mon");
        JButton btnTue12 = new JButton("Tue");
        JButton btnWed12 = new JButton("Wed");
        JButton btnThu12 = new JButton("Thu");
        JButton btnFri12 = new JButton("Fri");
        JButton btnSat12 = new JButton("Sat");
        JButton btnD1 = new JButton("");
        JButton btnD2 = new JButton("");
        JButton btnD3 = new JButton("");
        JButton btnD4 = new JButton("");
        JButton btnD5 = new JButton("1");
        JButton btnD6 = new JButton("2");
        JButton btnD7 = new JButton("3");
        JButton btnD8 = new JButton("4");
        JButton btnD9 = new JButton("5");
        JButton btnD10 = new JButton("6");
        JButton btnD11 = new JButton("7");
        JButton btnD12 = new JButton("8");
        JButton btnD13 = new JButton("9");
        JButton btnD14 = new JButton("10");
        JButton btnD15 = new JButton("11");
        JButton btnD16 = new JButton("12");
        JButton btnD17 = new JButton("13");
        JButton btnD18 = new JButton("14");
        JButton btnD19 = new JButton("15");
        JButton btnD20 = new JButton("16");
        JButton btnD21 = new JButton("17");
        JButton btnD22 = new JButton("18");
        JButton btnD23 = new JButton("19");
        JButton btnD24 = new JButton("20");
        JButton btnD25 = new JButton("21");
        JButton btnD26 = new JButton("22");
        JButton btnD27 = new JButton("23");
        JButton btnD28 = new JButton("24");
        JButton btnD29 = new JButton("25");
        JButton btnD30 = new JButton("26");
        JButton btnD31 = new JButton("27");
        JButton btnD32 = new JButton("28");
        JButton btnD33 = new JButton("29");
        JButton btnD34 = new JButton("30");
        JButton btnD35 = new JButton("31");

        DecPan2.add(btnSun12);
        DecPan2.add(btnMon12);
        DecPan2.add(btnTue12);
        DecPan2.add(btnWed12);
        DecPan2.add(btnThu12);
        DecPan2.add(btnFri12);
        DecPan2.add(btnSat12);
        DecPan2.add(btnD1);
        DecPan2.add(btnD2);
        DecPan2.add(btnD3);
        DecPan2.add(btnD4);
        DecPan2.add(btnD5);
        DecPan2.add(btnD6);
        DecPan2.add(btnD7);
        DecPan2.add(btnD8);
        DecPan2.add(btnD9);
        DecPan2.add(btnD10);
        DecPan2.add(btnD11);
        DecPan2.add(btnD12);
        DecPan2.add(btnD13);
        DecPan2.add(btnD14);
        DecPan2.add(btnD15);
        DecPan2.add(btnD16);
        DecPan2.add(btnD17);
        DecPan2.add(btnD18);
        DecPan2.add(btnD19);
        DecPan2.add(btnD20);
        DecPan2.add(btnD21);
        DecPan2.add(btnD22);
        DecPan2.add(btnD23);
        DecPan2.add(btnD24);
        DecPan2.add(btnD25);
        DecPan2.add(btnD26);
        DecPan2.add(btnD27);
        DecPan2.add(btnD28);
        DecPan2.add(btnD29);
        DecPan2.add(btnD30);
        DecPan2.add(btnD31);
        DecPan2.add(btnD32);
        DecPan2.add(btnD33);
        DecPan2.add(btnD34);
        DecPan2.add(btnD35);


        JanBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(JanPan1);
                getContentPane().add(JanPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        FebBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(FebPan1);
                getContentPane().add(FebPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        MarchBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(MarPan1);//Adding to content pane, not to Frame
                getContentPane().add(Marpan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });
        AprBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(AprPan1);//Adding to content pane, not to Frame
                getContentPane().add(AprPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        MayBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(MayPan1);//Adding to content pane, not to Frame
                getContentPane().add(Maypan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        JunBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(JunPan1);
                getContentPane().add(JunPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        JulBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(JulPan1);
                getContentPane().add(JulPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        AugBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(AugPan1);
                getContentPane().add(AugPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        SepBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(SepPan1);
                getContentPane().add(SepPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        OctBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(OctPan1);
                getContentPane().add(OctPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        NovBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(NovPan1);
                getContentPane().add(NovPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });

        DecBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                getContentPane().removeAll();
                getContentPane().add(DecPan1);//Adding to content pane, not to Frame
                getContentPane().add(DecPan2);
                getContentPane().add(MonthsPanel);
                repaint();
                printAll(getGraphics());
            }
        });
        setVisible(true);
    }
}
